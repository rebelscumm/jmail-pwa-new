// Proxy wrapper to reuse the existing google-login function implementation
// Exports the same handler from the sibling `api/google-login` function.
module.exports = require('../../google-login/index.js');


